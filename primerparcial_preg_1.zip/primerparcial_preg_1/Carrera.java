package primerparcial;
public class Carrera {
	private String nombre;
	private int nroe;
	private String [] listest=new String[50];
	private int nrog;
	private String [] listgru=new String[50];
	public Carrera() {
		nombre="informatica";
		nroe=6;
		listest[1]="alex";
		listest[2]="pedro";
		listest[3]="juan";
		listest[4]="miguel";
		listest[5]="fernando";
		listest[6]="roberto";
		nrog=2;
		listgru[1]="tobas";
		listgru[2]="tuna san andres";
	}	
	public Carrera(String x) {
		nombre=x;//medicina
		nroe=3;
		listest[1]="melisa";
		listest[2]="dana";
		listest[3]="claudia";		
		nrog=1;
		listgru[1]="yudo";		
	}
	public void mostrar() {
		System.out.println("nombre : "+nombre);
		System.out.println("num est : "+nroe);
		for (int i = 1; i <=nroe; i++) {
			System.out.println("nombre estudiante : "+listest[i]);
		}
		System.out.println("num grup : "+nrog);
		for (int i = 1; i <=nroe; i++) {
			System.out.println("nombre grupo : "+listgru[i]);
		}
	}
	public int masjoven(Estudiante[] e) {
		int edad=0;
		int min=Integer.MAX_VALUE;
		for (int i = 1; i <=nroe; i++) {
			String nom=listest[i];			
			for (int j = 0; j <e.length; j++) {
				if(nom.equals(e[j].getNombre())){
//					System.out.println(nom+"  "+e[j].getEdad());
					edad=e[j].getEdad();
				}
			}			
			if(min>edad){
				min=edad;
				
			}			
		}
		return min;
	}
	public String getNombre() {
		return nombre;
	}
	public int getNroe() {
		return nroe;
	}
	public String[] getListest() {
		return listest;
	}
	public int getNrog() {
		return nrog;
	}
	public String[] getListgru() {
		return listgru;
	}
	
}
