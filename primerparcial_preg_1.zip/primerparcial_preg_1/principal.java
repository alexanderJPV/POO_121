package primerparcial;

public class principal {
	public static void main(String[] args) {
		Estudiante e1=new Estudiante("alex", 10,12);
		Estudiante e2=new Estudiante("pedro", 2,123);
		Estudiante e3=new Estudiante("juan", 3, 1234);
		Estudiante e4=new Estudiante("miguel", 4, 12345);
		Estudiante e5=new Estudiante("melisa", 1, 123456);
		Estudiante e6=new Estudiante("dana", 6, 1234567);
		Estudiante e7=new Estudiante("claudia", 7, 12345678);
		Estudiante e8=new Estudiante("fernando", 8, 123456789);
		Estudiante e9=new Estudiante("roberto", 9, 1234567890);
		Estudiante []e={e1,e2,e3,e4,e5,e6,e7,e8,e9};
		
		Grupo g1=new Grupo();
		Grupo g2=new Grupo("yudo");
		Grupo g3=new Grupo("tuna",4);
		Grupo [] g={g1,g2,g3};
				
		Carrera c1=new Carrera();
		Carrera c2=new Carrera("medicina");		
		Carrera [] c={c1,c2};
		
		//a) Nos interesa saber a que gurpo pertenece un estudiante y cual es su edad
		
		for (int i = 0; i < e.length; i++) {
			String nomx=e[i].getNombre();
			for (int j = 0; j < g.length; j++) {
				if(g[j].nombregrupo(nomx)){
					System.out.println("\t"+nomx+"\t "+g[j].getNombre());	
				}
			}
		}
		//b)Cual es la carrera que tiene la mayor cantidad de grupos
		int may=Integer.MIN_VALUE;
		for (int i = 0; i < c.length; i++) {
			if(may<c[i].getNrog()){
				may=c[i].getNrog();
			}
		}
		for (int i = 0; i < c.length; i++) {
			if(may==c[i].getNrog()){
				System.out.println("nombre de carrera con mas grupos es : "+c[i].getNombre());
			}
		}
		//c) En que carrera se encuentra el estudiante mas joven
		int min=Integer.MAX_VALUE;
		for (int i = 0; i < c.length; i++) {
			int edadmin=c[i].masjoven(e);			
			if(min>edadmin){
				min=edadmin;
			}			
		}		
		for (int i = 0; i < c.length; i++) {
			int edadmin=c[i].masjoven(e);			
			if(min==edadmin){
				System.out.println("nombre de carrera con estudiante mas joven es :"+c[i].getNombre());
			}			
		}
	}
}
