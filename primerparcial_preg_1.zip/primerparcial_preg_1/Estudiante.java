package primerparcial;

public class Estudiante {	
	private String nombre;
	private int edad;	
	private int ci;
	public Estudiante(String nombre, int edad,int ci) {		
		this.nombre = nombre;
		this.edad = edad;
		this.ci=ci;
	}
	public void mostrar() {
		System.out.println("nombre : "+nombre);
		System.out.println("edad : "+edad);
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public int getCi() {
		return ci;
	}
	public void setCi(int ci) {
		this.ci = ci;
	}	
	
}
