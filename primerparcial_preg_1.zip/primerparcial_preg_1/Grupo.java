package primerparcial;


public class Grupo {
	private String nombre;
	private String tipo;
	private int nroint;
	private String [] listintegrantes=new String[50];
	
	public Grupo() {		
		nombre = "tobas";
		tipo = "baile";
		nroint=2;
		listintegrantes[1]="fernando";
		listintegrantes[2]="roberto";
	}
	public Grupo(String x) {		
		this.nombre = x;
		tipo = "gimanacia";
		nroint=3;
		listintegrantes[1]="melisa";
		listintegrantes[2]="dana";
		listintegrantes[3]="claudia";		
	}
	public Grupo(String x,int n) {		
		this.nombre = x;
		tipo = "musica";
		nroint=n;
		listintegrantes[1]="alex";
		listintegrantes[2]="pedro";
		listintegrantes[3]="juan";
		listintegrantes[4]="miguel";		
	}
	public boolean nombregrupo(String x) {
		boolean sw=false;
		for (int i = 1; i <=nroint; i++) {
			if(listintegrantes[i].equals(x)){
				sw=true;
			}
		}
		return sw;
	}
	public void mostrar() {
		// TODO Auto-generated method stub
		System.out.println("nombre grupo : "+nombre);
		System.out.println("tipo : "+tipo);
		for (int i = 1; i <=nroint; i++) {
			System.out.println("nombre : "+listintegrantes[i]);
		}
	}
	public String getNombre() {
		return nombre;
	}
	public String getTipo() {
		return tipo;
	}
	public int getNroint() {
		return nroint;
	}
	public String[] getListintegrantes() {
		return listintegrantes;
	}		
}
