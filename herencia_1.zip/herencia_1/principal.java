package herencia_1;

public class principal {
	public static void main(String[] args) {
		Cuadrado c1=new Cuadrado();
		c1.mostrar();
		//a) Crear un cuadrado de color negro y lado 5
		Cuadrado c2=new Cuadrado("negro", 5);
		c2.mostrar();
		
		Rectangulo r1=new Rectangulo();
		r1.mostrar();
		//b) crear un rectangulo rosado con 5 de base y 5 de lado
		Rectangulo r2=new Rectangulo("rosado", 5, 5);
		r2.mostrar();
		
		Triangulo t1=new Triangulo();
		t1.mostrar();				
		//C) crear un triangulo crojo con 5 base 5 de altura y 90 grados de angulo
		Triangulo t2=new Triangulo("rojo", 5, 5, 90);
		t2.mostrar();
		
		// d) Verificar si dos figuras tienen el mismo area
		if(c1.area()==c2.area())
			System.out.println("si");
		else
			System.out.println("no");	
		
	}
}
