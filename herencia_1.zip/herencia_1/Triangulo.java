package herencia_1;

import java.util.Scanner;

public class Triangulo extends Figura{
	private int base;
	private int altura;
	private int angulo;
	public Triangulo() {
		// TODO Auto-generated constructor stub
		base=2;
		altura=2;
		angulo=90;
	}
	public Triangulo(String color, int base, int altura, int angulo) {
		super(color);
		this.base = base;
		this.altura = altura;
		this.angulo = angulo;
	}
	@Override
	public void leer() {
		// TODO Auto-generated method stub
		super.leer();
		Scanner lee3=new Scanner(System.in);
		System.out.println("Intro base => ");
		base=lee3.nextInt();
		System.out.println("Intro altura => ");
		altura=lee3.nextInt();
		System.out.println("Intro angulo => ");
		angulo=lee3.nextInt();
	}
	@Override
	public void mostrar() {
		// TODO Auto-generated method stub
		super.mostrar();
		System.out.println("La base del Triangulo es : "+base);
		System.out.println("La altura del Triangulo es  : "+altura);
		System.out.println("El angulo del Triangulo es : "+angulo);  
	}
	public int area(){
		return ((base*altura)/2);		
	}
	public int getBase() {
		return base;
	}
	public int getAltura() {
		return altura;
	}
	public int getAngulo() {
		return angulo;
	}
	public void setBase(int base) {
		this.base = base;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	public void setAngulo(int angulo) {
		this.angulo = angulo;
	}	
	
}
