package herencia_1;

import java.awt.geom.Area;
import java.util.Scanner;

public class Rectangulo extends Figura{
	private int base;
	private int altura;
	public Rectangulo(String color, int base, int altura) {
		super(color);
		this.base = base;
		this.altura = altura;
	}
	public Rectangulo() {super();
		base=2;
		altura=2;
	}
	@Override
	public void leer() {
		// TODO Auto-generated method stub
		super.leer();
		Scanner lee2=new Scanner(System.in);
		System.out.println("Intro base => ");
		base=lee2.nextInt();
		System.out.println("Intro latura => ");
		altura=lee2.nextInt();
	}
	@Override
	public void mostrar() {
		// TODO Auto-generated method stub
		super.mostrar();
		System.out.println("La base es : "+base);
		System.out.println("La altura es  : "+altura);		
	}
	public int area(){
		return (base*altura);
	}
	public int perimetro(){
		return (2*base+2*altura);
	}
	public int getBase() {
		return base;
	}
	public int getAltura() {
		return altura;
	}
	public void setBase(int base) {
		this.base = base;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	
}
