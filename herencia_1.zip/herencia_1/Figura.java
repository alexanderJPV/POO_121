package herencia_1;

import java.util.Scanner;

public class Figura {
	protected String color;

	
	public Figura(String color) {		
		this.color = color;
	}
	public Figura() {
		this.color="azul";
	}
	public void leer() {
		Scanner lee=new Scanner(System.in);
		System.out.println("Intro color => "+color);
		color=lee.nextLine();
	}
	public void mostrar() {		
		System.out.println("El color es : "+color);
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
		
}
