package herencia_1;

import java.awt.geom.Area;
import java.util.Scanner;
//extends es la palabra reservada para definir que esta clase es uan extencion de la clase
//padre(Superclass) Figura de la cual heredaremos sus propiedades y caracteristicas
public class Cuadrado extends Figura{
	private int lado;
	//COnstructor por defecto la 
	//palabra reservada super hereda la 
	//funcion especifica de un metodo de la clase padre(superclass) Figura
	
	public Cuadrado() {super();
		this.lado=1;		
	}		
	//Constructor por parametros se observa 2 parametrs uno es de esta clase y el otro
	// es de la clase padre e ira mediante el super() al construtor por parametros
	// de la clase padre(superclass) Figura
	public Cuadrado(String color, int lado) {
		super(color);
		this.lado = lado;
	}	
	@Override
	public void leer() {
		// TODO Auto-generated method stub		
		super.leer();
		Scanner lee1=new Scanner(System.in);
		System.out.println("Intro lado => ");
		lado=lee1.nextInt();
	}
	@Override
	public void mostrar() {
		// TODO Auto-generated method stub
		super.mostrar();
		System.out.println("El lado es : "+lado);
	}
	public int area(){
		return (2*lado);
	}
	public int getLado() {
		return lado;
	}
	public void setLado(int lado) {
		this.lado = lado;
	}
	
	
}
