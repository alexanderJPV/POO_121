using System;

namespace ConsoleApplication
{
    public class Figura
    {
        protected string color;
        public Figura()
        {
            color="azul";
        }        
        public Figura(string color){
            this.color=color;
        }
        public void leer() {
            Console.WriteLine("Intro color => ");
            color=Console.ReadLine();
        }        
        public void mostrar() {  
            Console.WriteLine("El colore es  : "+color);
        }
        public string COLOR
        {
            get { return color;}
            set { color = value;}
        }        
    }
}