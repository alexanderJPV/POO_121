using System;
namespace ConsoleApplication
{
    public class Rectangulo:Figura
    {
        private int bas;
        private int altura;

        public Rectangulo():base()
        {
            bas=5;
            altura=5;
        }
        public void leer(){
            base.leer();
            bas=int.Parse(Console.ReadLine());
        }
        public void mostrar(){
            Console.WriteLine("El base es : "+bas);
            Console.WriteLine("La altura es  : "+altura);
        }

    }
}