using System;
namespace ConsoleApplication
{
    public class Cuadrado:Figura
    {
        private int lado;        
        public Cuadrado():base()
        {
            lado=2;
        }
        public Cuadrado(String color, int lado):base(color)
        {
              this.lado=lado;  
        }
        public void leer() {  
            base.leer();
            lado=int.Parse(Console.ReadLine());            
        }
        public void mostrar() { 
            base.mostrar();
            Console.WriteLine("El lado del Cuadrado es : "+lado);   
        }
        public int area() {  
            return 2*lado;
        }
        public int LADO
        {
            get { return lado;}
            set { lado = value;}
        }        
    }
}