﻿using System;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("\t Cuadrado 1");
            Cuadrado c1=new Cuadrado();
            c1.mostrar();
            Console.WriteLine("\t Cuadrado 2");
            Cuadrado c2=new Cuadrado("rojo",5);
            c2.mostrar();
            Console.WriteLine(c2.COLOR);
            //Console.ReadKey();
            Rectangulo r=new Rectangulo();
            r.mostrar();
            if(c1.COLOR.Equals(r.COLOR)){
                Console.WriteLine("si");
            }else{
                Console.WriteLine("si");
            }
        }
    }
}
