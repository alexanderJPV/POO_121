﻿using System;

namespace ConsoleApplication
{
    public class Programa
    {
        public static void Main(string[] args)
        {
            Ranking_TV a=new Ranking_TV();
            Ranking_TV b=new Ranking_TV();
            a.mostrar();
            //b)Sobrecargar una funcion para mostrar el canal mas visto en cada departamento
            a.canalmasvisto();
            //c)Sobrecargar una funcion para mostrar el canal mas visto en todos los departamentos 
            a.canalmasvisto("");
            //d) Sobrecargar el operador ! para ver si el promedio de la audiencia del canal X en todos 
            // los departamento es mayor a 50%
            if(!a)            
                Console.WriteLine("si");
            else
                Console.WriteLine("no");
            
            //e) Sobrecargar el operador ++ para ver si existe algun canal con audiencia menor a z%
            a++;                        
        }
    }
}
