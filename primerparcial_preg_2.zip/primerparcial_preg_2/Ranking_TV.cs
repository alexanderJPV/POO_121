using System;
namespace ConsoleApplication
{
    public class Ranking_TV
    {
        private string tipo;        
        private int fil=6;
        private int col=6;        
        private string [,] tv=new string[7,7];         
        
        public Ranking_TV()
        {
            tipo="popularidad";
          //tv[0,1]="Nombre canal "; tv[0,2]="Depto1"; tv[0,3]="Depto2"; tv[0,4]="Depto3"; tv[0,5]="Depto4"; tv[0,6]="Depto5";
            tv[1,1]="TV inter"; tv[1,2]="54"; tv[1,3]="76"; tv[1,4]="23"; tv[1,5]="87"; tv[1,6]="45";
            tv[2,1]="RTI     "; tv[2,2]="67"; tv[2,3]="97"; tv[2,4]="79"; tv[2,5]="56"; tv[2,6]="47";
            tv[3,1]="CTV     "; tv[3,2]="34"; tv[3,3]="65"; tv[3,4]="34"; tv[3,5]="37"; tv[3,6]="96";
            tv[4,1]="TV-PONG";  tv[4,2]="76"; tv[4,3]="53"; tv[4,4]="85"; tv[4,5]="68"; tv[4,6]="67";
            tv[5,1]="TV-UTRA";  tv[5,2]="87"; tv[5,3]="65"; tv[5,4]="34"; tv[5,5]="68"; tv[5,6]="75";
            tv[6,1]="KIDS-TV";  tv[6,2]="54"; tv[6,3]="78"; tv[6,4]="46"; tv[6,5]="56"; tv[6,6]="98";
        }        
        public void mostrar() { 
            Console.WriteLine("EL tipo del ranking es : "+tipo);
            Console.WriteLine("Num de fil"+fil);
            Console.WriteLine("Num de col :"+col);
            for (int i = 1; i <= fil; i++)
            {
                for (int j = 1; j <= col; j++)
                {
                    Console.Write("\t "+tv[i,j]);
                }
                Console.WriteLine();                                
            }
       } 
       public void canalmasvisto() {
            for (int i = 2; i <=col; i++)
            {

                int may=Int16.MinValue;
                int pos=0;
                for (int j = 1; j <=fil; j++)
                {
                    int aux=int.Parse(tv[j,i]);
                    if(aux>may){
                        may=aux;
                        pos=j;
                    }
                }
                Console.WriteLine("Canal mas visto en el dep "+(i-1)+" => "+tv[pos,1]+"  => "+may);
            }
       }
       public void canalmasvisto(String resp) 
       {                  
           int may=Int16.MinValue;                  
           for (int i = 1; i <=fil; i++)
           {
                int sum=0;                
                for (int j = 2; j <=col; j++)
                {
                    sum+=int.Parse(tv[i,j]);
                }           
                //Console.WriteLine(sum)         ;
                if(sum>may){
                    may=sum;
                    resp=tv[i,1];
                }                
            }    
            Console.WriteLine("canal mas visto :"+resp+" => "+may);
       }
       public static bool operator !(Ranking_TV z) {
           Boolean sw=false;
           string x="TV-UTRA";             
           for (int i = 1; i <=z.FIL; i++)
           {
               int sum=0;
               int promedio=0;
               if(z.tv[i,1].Equals(x))
               {
                   for (int j = 2; j <=z.COL; j++)
                   {
                       sum+=int.Parse(z.tv[i,j]);
                   }
                   promedio=sum/5;
                   if(promedio>50)
                   {
                       sw=true;
                   }
               }
                                             
            }             
           return sw;
       }
       public static Ranking_TV operator ++(Ranking_TV x)
       {
           int z=50;
           Boolean sw=false;
           for (int i = 1; i <=x.FIL; i++)
           {
               int sum=0;
               int promedio=0;                              
                   for (int j = 2; j <=x.COL; j++)
                   {
                       sum+=int.Parse(x.tv[i,j]);
                   }
                   promedio=sum/5;
                   // Console.WriteLine(promedio);
                   if(promedio<z)            
                   {       
                       sw=true;
                       break;
                   }
                   else                
                   {
                       sw=false;
                   }                                                                               
            }       
            if(sw) 
              Console.WriteLine(".....si");
            else
              Console.WriteLine(".....no");

           return x;
       }
       

       public int FIL
        {
            get { return fil;}
            set { fil = value;}
        }
        public int COL
        {
            get { return col;}
            set { col = value;}
        }
        public string [,] TV
        {
            get { return tv;}
            set { tv = value;}
        }
    }
}