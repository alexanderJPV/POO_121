﻿/*
 * Created by SharpDevelop.
 * User: root
 * Date: 10/02/2017
 * Time: 7:02
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace sobrecargaoperadores
{
	class Program
	{
		public static void Main(string[] args)
		{
			libro a=new libro(1,"uno","pancho villa",5);
			libro b=new libro();
			libro c=new libro();
			//mostrar
			a+=b;
			// TODO: Implement Functionality Here						
			if(a)
				Console.WriteLine("si");
			else{
				Console.WriteLine("no");			
			}
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}