﻿/*
 * Created by SharpDevelop.
 * User: root
 * Date: 10/02/2017
 * Time: 7:03
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace sobrecargaoperadores
{
	/// <summary>
	/// Description of libro.
	/// </summary>
	public class libro
	{
		private int cod;
		private string titulo;
		private string autor;
		private int pagina;
		public libro(int cod, string titulo,string autor,int pagina)
		{
			this.cod=cod;
			this.titulo=titulo;			
			this.autor=autor;
			this.pagina=pagina;
			
		}	
	    public libro()
		{			
			
		}	
		
		public static libro operator --(libro x){
			x.cod=int.Parse(Console.ReadLine());
			x.titulo=Console.ReadLine();
			x.autor=Console.ReadLine();
			x.pagina=int.Parse(Console.ReadLine());
			return x;
		}
		//mostar() operador ++		
		public static libro operator++(libro x){			
			
			Console.WriteLine("cod : "+x.cod);
			Console.WriteLine("titulo : "+x.titulo);
			Console.WriteLine("autor : "+x.autor);
			Console.WriteLine("pagina : "+x.pagina);						
			return x;
		}		
		public static libro operator +(libro x,libro y){
			libro c=new libro();
			Console.WriteLine("cod : "+x.cod);
			Console.WriteLine("titulo : "+x.titulo);
			Console.WriteLine("autor : "+x.autor);
			Console.WriteLine("pagina : "+x.pagina);								
		  	return c;
		}
		
		public static libro operator - (libro x,libro y){			
			libro c=new libro();			
			x.cod=int.Parse(Console.ReadLine());
			x.titulo=Console.ReadLine();
			x.autor=Console.ReadLine();
			x.pagina=int.Parse(Console.ReadLine());
			return c;
		}		
		public static bool operator true(libro x){
			return (x.pagina==0);
		}
		public static bool operator false(libro x){
			return (x.pagina>0);
		}
		
	}
}