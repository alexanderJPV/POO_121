using System;

namespace ConsoleApplication
{
    public class conjunto
    {
        private int n;
        private int [] ele=new int [50];    
        
        public conjunto()
        {
            this.n = 3;

            ele[1] = 5;
            ele[2] = 1;            
            ele[3] = 2;            
        }
        public conjunto(int n)
        {
            this.n = n;

            ele[1] = 1;
            ele[2] = 2;
            ele[3] = 3;
            ele[4] = 4;
        }
        public void mostrar() {
            Console.WriteLine("n : "+n);
            for (int i = 1; i <= n; i++)
            {
                Console.WriteLine("["+i+"] "+ele[i]);
            }
        }
        public void conjunto_Order (conjunto A) {
            for (int i = 1; i <= A.n; i++) {
                for (int j = 1; j <= A.n; j++) {
                    if (A.ele[i] < A.ele[j]) {
                        int aux = A.ele[j];
                        A.ele[j] = A.ele[i];
                        A.ele[i] = aux;
                    }
                }
            }
        }
        public void union_conjuntos (conjunto A, conjunto B,conjunto C) {
            int d = 0;
            for (int i = 1; i <= A.n ; i++) {
                d++;
                C.ele[d] = A.ele[i];
            }
            for (int i = 1; i <= B.n ; i++) {
                d++;
                C.ele[d] = B.ele[i];
            }
            C.n = d;
            C.conjunto_Order(C);
            Console.WriteLine("------------ mostrar conjunto C -------------");
            C.mostrar();
                Console.WriteLine("------------ primer metodo -------------");
            for (int i = 2; i <= C.n+1 ; i++) {
                if (C.ele[i-1] != C.ele[i]) {
                    Console.WriteLine("----> "+C.ele[i-1]);
                }
            }
        }
        public void diferencia_conjuntos (conjunto A,conjunto B,conjunto D) {
            int d = 0;
            for (int i = 1; i <= A.n ; i++) {
                d++;
                D.ele[d] = A.ele[i];
            }
            for (int i = 1; i <= B.n ; i++) {
                d++;
                D.ele[d] = B.ele[i];
            }
            D.n = d;
            conjunto_Order(D);
            Console.WriteLine("------------ mostrar conjunto D -------------");
            D.mostrar();
            Console.WriteLine("------------ primer metodo -------------");
            for (int i = 2; i <= D.n+1 ; i++) {
                if (D.ele[i-1] == D.ele[i]) {
                    Console.WriteLine("----> "+D.ele[i-1] +"    "+ D.ele[i]);
                    i++;
                } else {
                    Console.WriteLine(D.ele[i-1]);
                }
            }
        }
        //union de dos conjunto x={1,2,5} U y={1,2,3,4} => {1,2,3,4,5}
        public static conjunto operator +(conjunto x, conjunto y){
            conjunto c = new conjunto(); 
            int naux=x.n+y.n;
            int [] eleaux=new int [50];  
            int [] eleaux1=new int [50];  
            int [] eleaux2=new int [50];  
            eleaux1=x.ELE;
            eleaux2=y.ELE;
            //juntamos los elementos de los conjuntos 
            for (int i = 1; i <=x.n; i++)
            {
                eleaux[i] = eleaux1[i];   
            }
            int co = 1;
            for (int j = x.n+1; j <=naux;j++)
            {
                eleaux[j]=eleaux2[co];
                co++;
            }            
            // pero debemos recordar que en la union de conjuntos no hay elemntos repetidos
            //aqui eliminamos lo repetidos
            
            for (int i = 1; i <=naux; i++)
            {                
                for (int j = 1; j <=naux-1; j++)
                {
                     if(i!=j){                         
                        if(eleaux[i]==eleaux[j]) {
                            eleaux[j]=0;
                        }  
                     }                                                                 
                }                                                
            }
            int [] sinrepetido=new int [50];  
            int cont=1;            
            for (int i = 1; i <=naux; i++)
            {
                if(eleaux[i]!=0){
                    sinrepetido[cont]=eleaux[i];
                    cont++;
                }
            }
            c.ELE= sinrepetido;
            c.N = cont-1;
            return c;
        }
        //metodo para la diferencia de conjuntos conjunto x={1,2,5} conjunto y={1,2,3,4}
        //la diferencia sera {3,4,5}
        public static conjunto operator *(conjunto x,conjunto y){
            conjunto c=new conjunto();
            int [] eleaux=new int [50];  
            int [] eleauxiguales=new int [50];  
            int [] eleaux1=new int [50];  
            int [] eleaux2=new int [50];  
            eleaux1=x.ELE;
            eleaux2=y.ELE;            
            if(x.N<y.N)
            {   
                int cont=1;
                for (int i = 1; i <=y.N; i++)
                {                     
                    int valor=0;
                    bool sw=false;
                    for (int j = 1; j <=x.N; j++)
                    {
                        if(eleaux1[j]==eleaux2[i])
                        {
                            sw=true;
                            valor=eleaux2[i];                            
                            //Console.WriteLine(valor);
                            break;
                        }else{
                            sw=false;                            
                        }
                    }    
                    if(sw)                                    
                    {
                        eleauxiguales[cont]=valor;                    
                        cont++;
                    }                    
                }                
                int cont1=1;
                int valor1=0;
                for (int i =1 ; i <=x.N; i++)                {
                    bool sw=false;
                    valor1=0;                    
                    for (int j = 1; j <=cont; j++)
                    {                                               
                        if(eleaux1[i]==eleauxiguales[j]){                                                        
                            sw=false;                             
                            break;
                        }else{                                                        
                            valor1=eleaux1[i];
                            sw=true;                                                                                                                
                        }
                    }                    
                    if(sw){                        
                        eleaux[cont1]=valor1;
                        cont1++;
                    }                    
                }
                for (int i =1 ; i <=y.N; i++)                {
                    bool sw=false;
                    valor1=0;                    
                    for (int j = 1; j <=cont; j++)
                    {                                               
                        if(eleaux2[i]==eleauxiguales[j]){                                                        
                            sw=false;                             
                            break;
                        }else{                                                        
                            valor1=eleaux2[i];
                            sw=true;                                                                                                                
                        }
                    }                    
                    if(sw){                        
                        eleaux[cont1]=valor1;
                        cont1++;
                    }                    
                }
            c.ELE=eleaux;
            c.N=cont1-1;
            }                   
            return c;
        }
        public int N
        {
            get { return n; }
            set { n = value; }
        }
        public int [] ELE
        {
            get { return ele; }
            set { ele = value; }
        }
    }
}
//5 1 2 ----- 1 2 3 4 --> {1 2 3 4 5} union
//5 1 2 ----- 1 2 3 4 --> {3 4 5} diferencia