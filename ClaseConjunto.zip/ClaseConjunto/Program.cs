﻿using System;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            conjunto a = new conjunto();
            conjunto b = new conjunto(4);
            conjunto c = new conjunto(0);
            conjunto d = new conjunto(0);
           // conjunto union = new conjunto();
           // conjunto diferencia = new conjunto();
            Console.WriteLine("--------union--------");
             c=a+b;
             c.mostrar();
            Console.WriteLine("-------diferencia---------");
            d = a*b;
            d.mostrar();                       
           /*a.mostrar();
           b.mostrar();
           Console.WriteLine("----------- conjuntos union -----------------");
           a.union_conjuntos(a,b,c);           
           a.mostrar();
           b.mostrar();
           Console.WriteLine("----------- conjuntos diferencia -----------------");
           a.diferencia_conjuntos(a,b,d);*/
        }
    }
}
